import React from 'react';

export default function Footer() {
  return (
    <div
      className="container-fluid text-center footer "
      style={{ background: '#0B142B' }}>
      <p className="lead text-light p-3">bombayworks.com</p>
    </div>
  );
}
